define('ace/snippets/stylus', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "stylus";

});
